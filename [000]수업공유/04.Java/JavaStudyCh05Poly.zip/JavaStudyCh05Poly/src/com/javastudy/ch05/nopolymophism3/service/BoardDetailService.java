package com.javastudy.ch05.nopolymophism3.service;

// 게시 글 상세보기 요청을 처리하는 서비스 클래스
public class BoardDetailService {
	
	public String requestProcess() {		
		return "게시 글 상세보기를 화면에 띄운다.";		
	}
}
